
package eva2_14_final;


public class EVA2_14_FINAL {


    public static void main(String[] args) {
        Empleado empleado = new Empleado();
    }
    
public class Persona {
    private String nombre;

    public Persona(String nombre) {
        this.nombre = nombre;
    }
    public Persona(){
        this.nombre = "";
    }

        public String getNombre() {
            return nombre;
        }

        public void setNombre(String nombre) {
            this.nombre = nombre;
        }
    }
    
    
final public class Empleado extends Persona{ //ya no se puede heredar de empleado
    private String puesto;

            public Empleado(String puesto, String nombre) {
                super(nombre);
                this.puesto = puesto;
            }

            public Empleado(String puesto) {
                this.puesto = puesto;
            }
    }
public class CEO extends Empleado{//final limita la herencia

    }
}
