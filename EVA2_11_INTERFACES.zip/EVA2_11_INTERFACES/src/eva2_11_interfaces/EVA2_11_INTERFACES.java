
package eva2_11_interfaces;


public class EVA2_11_INTERFACES {


    public static void main(String[] args) {
        Empleado empleado = new Empleado("Gerente",100000,"Juean","Perez",40);
        empleado.mostrarMensaje();
    }
    
}
