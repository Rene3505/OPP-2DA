
package eva2_11_interfaces;


public class Empleado extends Persona implements Mensaje{
    private String puesto;
    private int salario;

    public Empleado(String puesto, int Salario, String nombre, String apellidos, int edad) {
        super(nombre, apellidos, edad);
        this.puesto = puesto;
        this.salario = Salario;
    }
    public Empleado(){
        super();
        this.puesto = "";
        this.salario = 0;
    }
    
    @Override
    public void mostrarMensaje(){
        System.out.println("Nombre: "+ getNombre());
        System.out.println("Apellidos: "+ getApellidos());
        System.out.println("Edad: "+ getEdad());
        System.out.println("Puesto: " +puesto);
        System.out.println("Salario: " +salario);
    }
}
