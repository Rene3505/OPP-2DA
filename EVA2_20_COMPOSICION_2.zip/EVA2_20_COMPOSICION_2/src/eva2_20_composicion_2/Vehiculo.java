
package eva2_20_composicion_2;

public class Vehiculo {
    private String marca;
    private String modelo;
    private String anio;
    private int numero;
    private Motor motor;
//hay que crearlos para usarlos
//el scceso; los datos estan encapsulados, accesibles a través del objeto.
    
    public Vehiculo(String marca, String modelo, String anio, int numero, Motor motor) {
        this.marca = marca;
        this.modelo = modelo;
        this.anio = anio;
        this.numero = numero;
        this.motor = motor;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getAnio() {
        return anio;
    }

    public void setAnio(String anio) {
        this.anio = anio;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public Motor getMotor() {
        return motor;
    }

    public void setMotor(Motor motor) {
        this.motor = motor;
    }

    @Override
    public String toString() {
        return "Vehiculo: "+ "\n" +
                "Marca: "+ marca + "\n"+
                "Modelo: "+modelo+"\n"+
                "Numero: " + numero+"\n"+
                "Año: "+anio;
    }

    
    
}
