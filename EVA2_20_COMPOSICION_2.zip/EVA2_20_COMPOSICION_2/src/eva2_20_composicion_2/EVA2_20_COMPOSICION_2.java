
package eva2_20_composicion_2;


public class EVA2_20_COMPOSICION_2 {


    public static void main(String[] args) {
        Motor motor = new Motor(5,'5',1.5);
        Vehiculo vehiculo = new Vehiculo("Pica piedra Corp","Chido,","10000 a.C.",1234,motor);
        System.out.println(vehiculo);
    }
    
}
