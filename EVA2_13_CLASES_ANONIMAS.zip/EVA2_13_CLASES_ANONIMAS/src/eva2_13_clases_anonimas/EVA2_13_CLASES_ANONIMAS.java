
package eva2_13_clases_anonimas;


public class EVA2_13_CLASES_ANONIMAS {

    public static void main(String[] args) {
        //Prueba prueba = new Prueba();
        //CLASE ANONIMA --> CLASE SIN NOMBRE 
        Prueba prueba = new Prueba() {
            @Override
            public void monstrarMensaje() {
                System.out.println("HOLA MUNDO");
            }
        };
    prueba.monstrarMensaje();
}
/*class UsarPrueba implements Prueba{

}*/
interface Prueba{
    public void monstrarMensaje();
}
    }