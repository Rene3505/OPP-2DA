
package eva2_17_polimorfismo;


public class EVA2_17_POLIMORFISMO {


public static void main(String[] args) {
        Cliente cliente = new Cliente("ASDF1234", 10000,30, "Juan","Perez");
        System.out.println("OBJETO CLIENTE");
        System.out.println(cliente.generarDatos());  
        Empleado empleado = new Empleado("Gerente", 10000, 30,"Juan","Perez");
        System.out.println("OBJETO EMPLEADO");
        System.out.println(empleado.generarDatos());
        //CLIENTE y EMPLEADO son PERSONAS (se derivan en la clase Persona)
        Persona persona;
        persona = cliente; //son tipos de datos dintintos
        System.out.println("CLIENTE EN UNA VARIABLE TIPO PERSONA");
        System.out.println(persona.generarDatos());
        Persona persona2;
        persona2 = empleado;
        System.out.println("Emplaedo EN UNA VARIABLE DE TIPO PERSONA");
        System.out.println(persona2.generarDatos());
        //Por herencia, los clientes derivan de Persona
        //int x = "Hola";
        System.out.println("USAR POLIMORFISMO PARA IMPRIMIR LOS DATOS");
        imprimirDatos(cliente);
        imprimirDatos(empleado);
        //NO SE PUEDE PONER UN OBJETO PERSONA EN UN CLIENTE O EMPLEADO
        Persona perso = new Persona(25,"Pedro","Páramo");
        imprimirDatos(perso);
        //CASTING:
        //Regresar las variables de tipo persona a su clase original
        Cliente clienteOriginal;
        clienteOriginal = (Cliente)persona;//dentro de persona hay un objeto de tipo cliente 
        //usar instanceof para evitar convertir objetos incompatibles
    }

     public static void imprimirDatos(Persona perso){
         System.out.println(perso.generarDatos());
         if(perso instanceof Cliente){
             System.out.println("Cliente");
         }else if(perso instanceof Empleado){
             System.out.println("Empleado");
         }else if(perso instanceof Persona){
             System.out.println("Persona");
         }
             
     }
}
