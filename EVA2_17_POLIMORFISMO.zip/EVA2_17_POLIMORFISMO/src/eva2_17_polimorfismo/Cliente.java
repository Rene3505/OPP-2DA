
package eva2_17_polimorfismo;
    //CLIENTE es una PERSONA
public class Cliente extends Persona{
    
    private String rfc;
    private double credito;
    
    public Cliente(String rfc, double credito, int edad, String nombre, String apellido) {
        super(edad, nombre, apellido);
        this.rfc = rfc;
        this.credito = credito;
    }

    public Cliente(String rfc, double credito) {
        this.rfc = "";
        this.credito = 0;
    }

    public String getRfc() {
        return rfc;
    }

    public void setRfc(String rfc) {
        this.rfc = rfc;
    }

    public double getCredito() {
        return credito;
    }

    public void setCredito(double credito) {
        this.credito = credito;
    }

    @Override
    public String generarDatos() {
    return super.generarDatos() +
            "Rfc: "+ rfc + "\n"+
            "Credito: "+credito;    
    }
}
