
package eva2_17_polimorfismo;
    //EMPLEADO es una PERSONA
public class Empleado extends Persona{
    
private String puesto;
private int salario;
    
public Empleado(String puesto, int salario, int edad, String nombre, String apellido){
        super(edad, nombre, apellido);
        this.puesto = puesto;
        this.salario = salario;
    }

public Empleado(String puesto, int salario) {
        this.puesto = "";
        this.salario = 0;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    public int getSalario() {
        return salario;
    }

    public void setSalario(int salario) {
        this.salario = salario;
    }

    @Override
    public String generarDatos() {
    return super.generarDatos()+
         "Puesto: "+puesto+"\n"+
         "Salario: "+salario;
    }
}
