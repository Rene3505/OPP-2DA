
package eva2_18_composicion;

public class Direccion {
    private String calle;
    private String colonia;
    private int numero;

    public Direccion(String calle, String colonia, int numero) {
        this.calle = calle;
        this.colonia = colonia;
        this.numero = numero;
    }
    public Direccion(){
        this.calle = "";
        this.colonia = "";
        this.numero = 0;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getColonia() {
        return colonia;
    }

    public void setColonia(String colonia) {
        this.colonia = colonia;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }
    
}
