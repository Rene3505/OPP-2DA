
package eva2_18_composicion;
             
public class Persona {
    private int edad;
    private String nombre;
    private String apellido;
    private Direccion direccion;

//CONSTRUCTORES

    public Persona(int edad, String nombre, String apellido, String calle, String colonia, int numero) {
        this.edad = edad;
        this.nombre = nombre;
        this.apellido = apellido;
        this.direccion = new Direccion(calle, colonia, numero);
    }
    
    public Persona() {
        this.edad = 0;
        this.nombre = "";
        this.apellido = "";
        this.direccion = new Direccion();
    }  

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public Direccion getDireccion() {
        return direccion;
    }

    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
    }
    
}
