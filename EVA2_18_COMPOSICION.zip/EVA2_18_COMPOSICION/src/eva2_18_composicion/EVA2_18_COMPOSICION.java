
package eva2_18_composicion;


public class EVA2_18_COMPOSICION {


    public static void main(String[] args) {
        Persona persona = new Persona(20, "Rene", "Garcia", "ELDIABLO", "LACEBOLLA", 1234);
        System.out.println("Nombre: "+ persona.getNombre());
        System.out.println("Apellido: "+ persona.getApellido());
        System.out.println("Edad: "+persona.getEdad());
        System.out.println("Calle: "+ persona.getDireccion().getCalle());
        System.out.println("Colonia: "+persona.getDireccion().getColonia());
        System.out.println("Numero: "+persona.getDireccion().getNumero());
        //SE CAMBIA LA DIRECCION DE LA PERSONA:
        Direccion direccion = new Direccion("ELHUESO","",5678);
        persona.setDireccion(direccion);
    }
    
}
