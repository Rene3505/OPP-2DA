
package eva2_9_abstract;


public class EVA2_9_ABSTRACT {


    public static void main(String[] args) {
        Empleado empleado = new Empleado("123ASDF", 100000, "Gerente", "Juan", "Perez", 20, 2020);
        empleado.imprimirDatos();
    }
    
}
