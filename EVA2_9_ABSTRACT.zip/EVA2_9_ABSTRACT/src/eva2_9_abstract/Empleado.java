
package eva2_9_abstract;


public class Empleado extends Persona{
    private String claveEmpleado;
    private double salario;
    private String puesto;
    private int ingreso;

    public Empleado(String claveEmpleado, double salario, String puesto, String nombre, String apellidos, int edad, int ingreso) {
        super(nombre, apellidos, edad);
        this.claveEmpleado = claveEmpleado;
        this.salario = salario;
        this.puesto = puesto;
        this.ingreso = ingreso;
    }
    public Empleado() {
        super();
        claveEmpleado = "";
        salario = 0;
        puesto = "";
        ingreso = 0;
    }    

    public int getIngreso() {
        return ingreso;
    }

    public void setIngreso(int ingreso) {
        this.ingreso = ingreso;
    }

    public String getClaveEmpleado() {
        return claveEmpleado;
    }

    public void setClaveEmpleado(String claveEmpleado) {
        this.claveEmpleado = claveEmpleado;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String getApellidos() {
        return apellidos;
    }

    @Override
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    @Override
    public int getEdad() {
        return edad;
    }

    @Override
    public void setEdad(int edad) {
        this.edad = edad;
    }
    
    @Override
    public int calcularAntiguedad(){
        return 2026 - ingreso ;
    }
    
     public void imprimirDatos(){
         System.out.println("Nombre: "+nombre);
         System.out.println("Apellidos: "+apellidos);
         System.out.println("Edad: "+edad);
         //ATRIBUTOS DE MI CLASE
         System.out.println("Clave de empleado: "+claveEmpleado);
         System.out.println("Salario: "+salario);
         System.out.println("Antiguedad: "+ calcularAntiguedad());
     }       
}
