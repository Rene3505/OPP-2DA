
package eva2_6_herencia;


public class EmpleadoHonorarios extends Empleado{
    private int horas;

    public EmpleadoHonorarios(int horas, String nombre, String apellidos, String claveEmpleado, double salario) {
        super(nombre, apellidos, claveEmpleado, salario);
        this.horas = horas;
    }

    public int getHoras() {
        return horas;
    }

    public void setHoras(int horas) {
        this.horas = horas;
    }
    public double calcularSalario(){
        return horas * getSalario();
    }
    
    @Override
    public String toString(){
        return super.toString() +
                "Horas: " + horas + "\n" +
                "Salario: " +calcularSalario();
                
    }
    
}
