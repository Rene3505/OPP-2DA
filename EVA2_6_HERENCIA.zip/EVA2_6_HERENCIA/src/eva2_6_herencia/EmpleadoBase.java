
package eva2_6_herencia;


public class EmpleadoBase extends Empleado{

    public EmpleadoBase(String nombre, String apellidos, String claveEmpleado, double salario) {
        super(nombre, apellidos, claveEmpleado, salario);
    }
    public double calcularSalario(){
        return getSalario();
    }

    @Override
    public String toString() {
        return super.toString() +
                "Numero: " +getClaveEmpleado()+ "\n" +
                "Salario: "+ calcularSalario() + "\n";
    }
    
    
}
