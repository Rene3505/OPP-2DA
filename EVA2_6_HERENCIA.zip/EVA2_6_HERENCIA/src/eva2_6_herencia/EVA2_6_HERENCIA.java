
package eva2_6_herencia;


public class EVA2_6_HERENCIA {


    public static void main(String[] args) {
        Empleado empleado = new Empleado("Victor","Garcia Alvarado", "ASDF1234", 1000);
        System.out.println(empleado);
        
        EmpleadoHonorarios empleadoHono = new EmpleadoHonorarios(40,"Victor","Garcia Alvarado", "ASDF1234", 1000);
        System.out.println(empleadoHono);
    }
    
}
