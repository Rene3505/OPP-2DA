
package eva2_10_interfaces;

public interface Mensaje {
    //public int valor = 100;//Normalmente no se usan mucho
    public void mostrarMensaje(); //La interfaz solo tiene metodos publicos abstractos
}
