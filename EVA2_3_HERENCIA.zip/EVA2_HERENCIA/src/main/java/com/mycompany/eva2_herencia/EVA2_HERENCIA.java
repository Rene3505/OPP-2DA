
package com.mycompany.eva2_herencia;


public class EVA2_HERENCIA {

    public static void main(String[] args) {
        System.out.println("-----CLASE ANIMAL-----");
        Animal animal = new Animal();
        animal.comer();
        System.out.println("-----CLASE MAMIFERO-----");
        Mamifero mamifero = new Mamifero();
        mamifero.comer();
        mamifero.tenerPelo();
        System.out.println("-----CLASE PERSONA-----");
        Persona persona = new Persona();
        persona.comer();
        persona.tenerPelo();
        persona.pensar();
    }
}

class Animal{ //CLASE BASE, SUPERCLASE, CLASE PADRE
    public Animal (){
        System.out.println("Clase animal");
    }
    public void comer(){
        System.out.println("Animal: comer!!");
    }
}

class Mamifero extends Animal{ //CLASE DERIVADA, SUBCLASE, CLASE HIJO
    public Mamifero(){
        System.out.println("Clase mamifero");
    }
        public void tenerPelo(){
            System.out.println("Mamifero: tener pelo!!!");
        }
}

class Persona extends Mamifero{
    public Persona(){
        System.out.println("Clase Persona");
    }
    public void pensar(){
        System.out.println("Persona: piensa!!!!");
    }
}