
package eva2_5_ejemplo_herencia;


public class Persona {
    private String nombre;
    private String apPaterno;
    private String apMaterno;
    private String rfc;
    private int edad;
    private char genero;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApPaterno() {
        return apPaterno;
    }

    public void setApPaterno(String apPaterno) {
        this.apPaterno = apPaterno;
    }

    public String getApMaterno() {
        return apMaterno;
    }

    public void setApMaterno(String apMaterno) {
        this.apMaterno = apMaterno;
    }

    public String getRfc() {
        return rfc;
    }

    public void setRfc(String rfc) {
        this.rfc = rfc;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public char getGenero() {
        return genero;
    }

    public void setGenero(char genero) {
        this.genero = genero;
    }
    public Persona(){
    nombre = "";
    apPaterno = "";
    apMaterno = "";
    rfc = "";
    edad = 0;
    genero = ' ';
    
    }
    public Persona(String nombre, String apPaterno, String apMaterno, String rfc, int edad, char genero) {
        this.nombre = nombre;
        this.apPaterno = apPaterno;
        this.apMaterno = apMaterno;
        this.rfc = rfc;
        this.edad = edad;
        this.genero = genero;
    }
    
     public String generarNombreCom(){
     
     return nombre + " " + apPaterno + " " + apPaterno;
     }
     
     public String regresarGenero(){
     switch(genero){
         case 'H':
             return "Hombre";
         case 'M':
             return "Mujer";
         case 'O':
            return "Otro";
         default:
             return "No definido";
        }
     }
     
     public void imprimirDatos(){
         System.out.println("-----Persona-----");
         System.out.println("Nombre: "+ generarNombreCom());
         System.out.println("Edad: "+edad);
         System.out.println("Genero: "+regresarGenero());
         System.out.println("RFC: "+rfc);
     }
     
}


