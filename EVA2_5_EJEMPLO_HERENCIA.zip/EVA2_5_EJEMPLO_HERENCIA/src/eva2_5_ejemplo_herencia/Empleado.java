
package eva2_5_ejemplo_herencia;


public class Empleado extends Persona{
    private String numeroEmpleado;
    private String puesto;
    private double salario;
    
    public Empleado(){
    super();
    this.numeroEmpleado = "";
    this.puesto = "";
    this.salario = 0;
    }

    public Empleado(String numeroEmpleado, String puesto, double salario, String nombre, String apPaterno, String apMaterno, String rfc, int edad, char genero) {
        super(nombre, apPaterno, apMaterno, rfc, edad, genero);//PERSONA
        this.numeroEmpleado = numeroEmpleado;
        this.puesto = puesto;
        this.salario = salario;//EMPLEADO
        
        //CONSTRUCTOR DE PERSONA + EMPLEADO
    }
    
    /*public void imprimirDatosEmpleado(){
        imprimirDatos(); //metodo de persona
        System.out.println("NO de empleado: "+ numeroEmpleado);
        System.out.println("Puesto: "+ puesto);
        System.out.println("Salario: "+ salario +" pesos");
    }*/
    //SOBREESCRITURA (SOBRECARGA) DE MÉTODOS
    @Override
    public void imprimirDatos(){
        super.imprimirDatos();//incorporamos la funcionalidad del metodo
        System.out.println("NO de empleado: "+ numeroEmpleado);
        System.out.println("Puesto: "+ puesto);
        System.out.println("Salario: "+ salario +" pesos");
    }
    
    @Override
    public String toString(){
     String resu = "-------DATOS DEL EMPLEADO--------" + "\n" +
             "Nombre: " + generarNombreCom() + "\n" +
             "Edad: " + getEdad() + "\n" +
             "RFC " + getRfc() + "\n" +
             "NO de empleado: "+ numeroEmpleado + "\n" +
             "Puesto: "+ puesto + "\n" +
             "Salario: "+ salario +" pesos" + "\n"; 
     return resu;   
    }
}
