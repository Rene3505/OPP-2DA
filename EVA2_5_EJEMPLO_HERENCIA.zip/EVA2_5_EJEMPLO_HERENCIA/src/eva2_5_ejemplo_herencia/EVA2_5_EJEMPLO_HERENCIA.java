
package eva2_5_ejemplo_herencia;


public class EVA2_5_EJEMPLO_HERENCIA {
    public static void main(String[] args) {
        
        Persona persona = new Persona("Juan","Perez","Jolote","ASDF1234",50,'H');
        persona.imprimirDatos();
        
        Empleado empleado = new Empleado("1","Gerente",1000000,"Rene","Garcia","Alvarado","ASDF1234",50,'H');
        //empleado.imprimirDatos();
        System.out.println(empleado);

    }
    
}
