
package com.mycompany.eva2_4_constructores;


public class EVA2_4_CONSTRUCTORES {

    public static void main(String[] args) {
        Empleado empleado = new Empleado(1000);
        
    }
}

class Persona{//BASE, SUPERCLASE, CLASE PADRE
public Persona (){
    System.out.println("Clase persona");
    }
}

class Empleado extends Persona {//DERIVADA, SUBCLASE, HUJO
    //super --> acceso a lo publico o protegido de la superclase
    public Empleado(){
        super();//CONSTRUCTOR DE LA SUPERCLASE
    }
    
    public Empleado (int salario) {
        super();
    System.out.println("Empleado: constructor con argumentos");
    }
}


