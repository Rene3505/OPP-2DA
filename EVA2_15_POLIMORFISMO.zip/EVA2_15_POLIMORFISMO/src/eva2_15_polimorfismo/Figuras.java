
package eva2_15_polimorfismo;


public interface Figuras {
    double calcularArea();
    double calcularPerimetro();
}
