
package eva2_15_polimorfismo;


public class Circulo implements Figuras{
    private double radio;

    public Circulo(double radio) {
        this.radio = radio;
    }
    public Circulo (){
        radio = 0;
    }

    public double getRadio() {
        return radio;
    }

    public void setRadio(double radio) {
        this.radio = radio;
    }

    @Override
    public double calcularArea() {
        return Math.PI * (radio*radio);
    }

    @Override
    public double calcularPerimetro() {
        return Math.PI*(radio*2) ;
    }
    
}
