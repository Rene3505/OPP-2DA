
package eva2_15_polimorfismo;


public class EVA2_15_POLIMORFISMO {


    public static void main(String[] args) {
        Circulo circulo = new Circulo(50);
        System.out.println("CIRCULO:");
        imprimirArea(circulo);
        System.out.println("Perimetro = "+ circulo.calcularPerimetro());
        Rectangulo rectangulo = new Rectangulo(20,30);
        System.out.println("RECTANGULO:");
        imprimirArea(rectangulo);
        System.out.println("Perimetro = "+ rectangulo.calcularPerimetro());
    }
    
    public static void imprimirArea(Circulo circulo){
        System.out.println("Area = "+ circulo.calcularArea());    
    }
    public static void imprimirArea(Rectangulo rectangulo){
        System.out.println("Area = "+ rectangulo.calcularArea());    
    }
       
}
