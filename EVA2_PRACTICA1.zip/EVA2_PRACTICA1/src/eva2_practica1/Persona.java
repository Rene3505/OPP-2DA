
package eva2_practica1;

public class Persona {
    
}
