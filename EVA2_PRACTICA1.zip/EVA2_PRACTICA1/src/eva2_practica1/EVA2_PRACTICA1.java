
package eva2_practica1;


public class EVA2_PRACTICA1 {


    public static void main(String[] args) {
        Persona persona = new Persona();
        System.out.println(persona);
    }
    
}
