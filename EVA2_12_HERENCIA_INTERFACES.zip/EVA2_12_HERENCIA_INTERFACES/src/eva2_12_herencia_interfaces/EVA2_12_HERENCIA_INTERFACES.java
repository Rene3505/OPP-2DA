
package eva2_12_herencia_interfaces;

public class EVA2_12_HERENCIA_INTERFACES {


    public static void main(String[] args) {
        
    }
    
}
interface Prueba{
    void mostrarMensaje();
}
interface OtraPrueba extends Prueba{
    void mostrarSaludo(String mensaje);
}

class Demostracion implements OtraPrueba{

    @Override
    public void mostrarSaludo(String mensaje) {
        System.out.println(mensaje);
    }

    @Override
    public void mostrarMensaje() {
        System.out.println("Jelo uorl");
    }
}