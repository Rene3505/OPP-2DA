
package eva2_7_figuras;

public class Triangulo extends Figuras {
    private double base;
    private double altura;
    private double lad1;
    private double lad2;
    private double lad3;

    public Triangulo(double base, double altura, double lad1, double lad2, double lad3) {
        this.base = base;
        this.altura = altura;
        this.lad1 = lad1;
        this.lad2 = lad2;
        this.lad3 = lad3;
    }
    
    public Triangulo(){
        this.base = 0;
        this.altura = 0;
        this.lad1 = 0;
        this.lad2 = 0;
        this.lad3 = 0;    
    }

    public double getBase() {
        return base;
    }

    public void setBase(double base) {
        this.base = base;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public double getLad1() {
        return lad1;
    }

    public void setLad1(double lad1) {
        this.lad1 = lad1;
    }

    public double getLad2() {
        return lad2;
    }

    public void setLad2(double lad2) {
        this.lad2 = lad2;
    }

    public double getLad3() {
        return lad3;
    }

    public void setLad3(double lad3) {
        this.lad3 = lad3;
    }
    
    @Override
    public double calcularArea(){
        return (base*altura)/2;
    }
    
    @Override
    public double calcularPerimetro(){
        return lad1+lad2+lad3;
    }
    
    @Override
    public String toString(){
     String resu = "-------TRIANGULO--------" + "\n" +
             "Base: " + getBase() + "\n" +
             "Altura: " + getAltura() + "\n" +
             "Lado 1: " + getLad1() + "\n" +
             "Lado 2: " + getLad2() + "\n" +
             "Lado 3: " +getLad3() + "\n" +
             "Area: " + calcularArea() + "\n" +
             "Perimetro: " + calcularPerimetro() + "\n" ;
     return resu;     
    }
}
