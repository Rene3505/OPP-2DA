
package eva2_7_figuras;

public class Figuras {
    
    public double calcularArea(){
    return 0;
    }
    
    public double calcularPerimetro(){
    return 0;
    }
    
}
