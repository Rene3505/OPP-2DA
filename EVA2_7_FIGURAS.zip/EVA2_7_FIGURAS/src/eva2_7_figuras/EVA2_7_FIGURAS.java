
package eva2_7_figuras;


public class EVA2_7_FIGURAS {

    public static void main(String[] args) {
        Triangulo triangulo = new Triangulo(9,10,11,9,11);
        System.out.println(triangulo);
        Circulo circulo = new Circulo(5.5);
        System.out.println(circulo);
    }
    
}
