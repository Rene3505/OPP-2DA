
package eva2_7_figuras;


public class Circulo extends Figuras{
    private double radio;

    public Circulo(double radio) {
        this.radio = radio;
    }
    
    public Circulo(){
    this.radio = 0;
    }

    public double getRadio() {
        return radio;
    }

    public void setRadio(double radio) {
        this.radio = radio;
    }
    
    @Override
    public double calcularArea(){
    return ((radio*radio))*Math.PI ;
    }
    @Override
    public double calcularPerimetro(){
    return Math.PI*(radio*2) ;
    }
    @Override
    public String toString(){
    String resu = "-------CIRCULO--------" + "\n" +
            "Radio: " + getRadio() + "\n" +
             "Area: " + calcularArea() + "\n" +
             "Perimetro: " + calcularPerimetro() + "\n" ;
     return resu;     
    }
}
