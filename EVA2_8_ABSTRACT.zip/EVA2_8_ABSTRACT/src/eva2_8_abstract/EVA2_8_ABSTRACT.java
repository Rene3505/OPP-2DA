
package eva2_8_abstract;


public class EVA2_8_ABSTRACT {


    public static void main(String[] args) {
        //Figuras figura = new Figuras(); NO SE PUEDE INSTANCIAR
    }
    
}
