
package eva2_8_abstract;

//UNA CLASE ABSTRACTA NO PERMITE CREAR OBJETOS
//UNA CLASE ABSTRACTA PUEDE TENER CERO O MAS METODOS ABSTRACTOS
//UN METODO ABSTRACTO ES UN METODO SIN IMPLEMENTACION (SIN LLAVES)
abstract public class Figuras {
    abstract public double calcularArea();
    abstract public double calcularPerimetro();
}
