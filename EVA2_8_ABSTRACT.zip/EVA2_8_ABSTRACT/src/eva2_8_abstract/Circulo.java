
package eva2_8_abstract;


public class Circulo extends Figuras{
    private double radio;
    
    public Circulo(){
    radio = 0;
    }

    public Circulo(double radio) {
        this.radio = radio;
    }

    public double getRadio() {
        return radio;
    }

    public void setRadio(double radio) {
        this.radio = radio;
    }

    public double calcularArea() {
        return Math.PI * Math.pow(radio, 2);
    }

    public double calcularPerimetro() {
        return Math.PI*(radio*2);
    }
        @Override
    public String toString(){
    String resu = "-------CIRCULO--------" + "\n" +
            "Radio: " + getRadio() + "\n" +
             "Area: " + calcularArea() + "\n" +
             "Perimetro: " + calcularPerimetro() + "\n" ;
     return resu;     
    }
}
